   /***
* Name: penang_traffic_flow_simulation
* Author: Raihanah Adawiyah Shaharuddin
* Description:  20 s traffic light, off peak 1576 vehicles, peak 6305, vehicle composition: (64% cars, 1.1 % bus, 1.9% lorry)
* [Car-blue | Wanderer-green | Bus-red | Lorry-black]
***/

model penang_traffic_flow_simulation

global {   
	bool simple_data <- false;
	file shape_file_roads  <- file("../includes/Road.shp") ;
	file shape_file_nodes  <- file("../includes/Node.shp");
	file shape_file_bounds <-file("../includes/Road.shp");
	file shape_file_buildings <- file("../includes/Building.shp");
	geometry shape <- envelope(shape_file_bounds) + 50.0;
	
	float step <- 1#s;
	
	graph road_network;  
	graph rapid_route;
// Total number of vehicles
int nb_veh <- 1576; // 6305 (peak), 3135 (non-peak), 1576 (non-peak2)

// Composition percentages
float composition_people_wander <- 64.0;   // Combined percentage for people and wander
float composition_bus <- 1.1;             // Percentage for buses
float composition_lorry <- 1.9;           // Percentage for lorries
float composition_motorcycle <- 33.1;         // Percentage of motorcycle (not included in simulation

// Calculate the number of vehicles for each category
int nb_people_wander <- round(nb_veh * (composition_people_wander / 100));  // 91.2% of total vehicles
int nb_bus <- round(nb_veh * (composition_bus / 100));                      // 2.8% of total vehicles
int nb_lorry <- round(nb_veh * (composition_lorry / 100));                  // 1.6% of total vehicles

// Assume a 50/50 split for nb_people and nb_wander within the people_wander group
int nb_people <- round(nb_people_wander * 0.5);    // 70% of nb_people_wander as people
int nb_wander <- nb_people_wander - nb_people;    // Remaining 50% as wander
	 
	init {  
		create building from: shape_file_buildings with:[name::string(read("building"))];
		create intersection from: shape_file_nodes with:[is_traffic_signal::(read("type") = "traffic_signals"), is_crossing::(read("purpose") = "crossing"), name::string(read("agenda")), colourTL::string(read("colourTL")), timingTL::int(read("timingTL")),
			purpose::string(read("purpose"))];
		ask intersection where each.is_traffic_signal {
			counter <- timingTL;
			stop << (colourTL="red")? roads_in: []; //define first stopping road before assign action, so that vehicle stop and move accordingly since step 1.
			if (colourTL="green") {
				do to_green;
			} else {
				do to_red;
			}
		}
		ask intersection where each.is_crossing {
			counter <- timingTL;
			stop << (colourTL="red")? roads_in: []; 
			if (colourTL="green") {
				do to_green;
			} else {
				do to_red;
			}
		}
		//create intersection from: shape_file_nodes with:[is_traffic_signal::(read("type") = "traffic_signals"), name::string(read("agenda")), operator::string(read("operator"))];
		create road from: shape_file_roads with:[lanes::int(read("lanes")), oneway::string(read("oneway")), maxspeed::float(read("maxspeed")), purpose::string(read("purpose"))] {
			//geom_display <- shape + (2.5 * lanes);
			geom_display <- shape;
			//maxspeed <-  80 °km/°h;
			switch oneway {
					match "no" { 
					create road {
						lanes <- myself.lanes;
						shape <- polyline(reverse(myself.shape.points));
						maxspeed <- myself.maxspeed;
						geom_display  <- myself.geom_display;
						linked_road <- myself;
						myself.linked_road <- self;
					}
				}
				match "yes" {
					create road {
						lanes <- myself.lanes;
						shape <- polyline(myself.shape.points);
						maxspeed <- myself.maxspeed;
						geom_display  <- myself.geom_display;
						shape <- polyline(shape.points);
					}
				}
			}
		}	
		
		//map general_speed_map <- road as_map (each::(each.shape.perimeter / each.maxspeed));
		map general_speed_map <- road as_map (each::each.maxspeed);
		road_network <- (as_driving_graph(road, intersection))  with_weights general_speed_map;
		
		//rapid_route <- (as_driving_graph(road, intersection where (each.operator='Rapid Penang')))  with_weights general_speed_map;
		
		create people number: nb_people { 
			//add one_of(building where (each.name='house')) to:agenda1;
			add one_of(building) to:agenda1;
			add one_of(intersection where (each.name='agenda2')) to:agenda2;
			//max_speed <- 120 °km/°h;
			vehicle_length <- 4.0 °m;
			right_side_driving <- false;
			proba_lane_change_up <- rnd(500) / 500;
			proba_lane_change_down <- 0.5+ (rnd(250) / 500);
			security_distance_coeff <- 3 - rnd(2000) / 1000;  
			proba_respect_priorities <- 1.0 - rnd(200/1000);
			//proba_respect_priorities <- rnd(0.8,1.0);
			proba_respect_stops <- [1.0];
			//proba_block_node <- 0.0;
			//proba_block_node <- 0.5;
			proba_use_linked_road <-  rnd(10) / 10000;
			max_acceleration <- 0.5 + rnd(2370) / 1000;
			speed_coeff <- 3.74 - (rnd(2940) / 1000);
			threshold_stucked <-int ( (1 + rnd(5))°mn);
			//proba_breakdown <- 0.00001;
			location <- any_location_in(one_of(agenda1));
		}
		create wanderer number: nb_wander { 
			//max_speed <- 120 °km/°h;
			vehicle_length <- 4.0 °m;
			right_side_driving <- false;
			proba_lane_change_up <- rnd(500) / 500;
			proba_lane_change_down <- 0.5+ (rnd(250) / 500);
			security_distance_coeff <- 3 - rnd(2000) / 1000;  
			proba_respect_priorities <- 1.0 - rnd(200/1000);
			proba_respect_stops <- [1.0];
			//proba_block_node <- 0.0;
			proba_use_linked_road <- 0.0;
			max_acceleration <- 0.5 + rnd(2370) / 1000;
			speed_coeff <- 3.74 - (rnd(2940) / 1000);
			threshold_stucked <-int ( (1 + rnd(5))°mn);
			//proba_breakdown <- 0.00001;
			location <- any_location_in(one_of(building));
			
		}
		create bus number: nb_bus {
			//max_speed <- 100 °km/°h; //max speed lower than people
			vehicle_length <- 10.3 °m;  // avg length of bus
			right_side_driving <- false;
			proba_lane_change_up <- rnd(500) / 500;
			proba_lane_change_down <- 0.5+ (rnd(250) / 500);
			security_distance_coeff <- 3 - rnd(2000) / 1000;  
			proba_respect_priorities <- 1.0 - rnd(200/1000);
			proba_respect_stops <- [1.0];
			//proba_block_node <- 0.0;
			proba_use_linked_road <- 0.0;
			max_acceleration <- 0.5 + rnd(500) / 1000;
			speed_coeff <- 2.77 - (rnd(1970) / 1000);
			location <- any_location_in(one_of(intersection));
		}	
		create lorry number: nb_lorry {
			//max_speed <- 100 °km/°h; //max speed lower than people
			vehicle_length <- 7.5 °m;  // avg length of bus
			right_side_driving <- false;
			proba_lane_change_up <- rnd(500) / 500;
			proba_lane_change_down <- 0.5+ (rnd(250) / 500);
			security_distance_coeff <- 3 - rnd(2000) / 1000;    
			proba_respect_priorities <- 1.0 - rnd(200/1000);
			proba_respect_stops <- [1.0];
			//proba_block_node <- 0.0;
			proba_use_linked_road <- 0.0;
			max_acceleration <- 0.5 + rnd(500) / 1000;
			speed_coeff <- 2.77 - (rnd(1970) / 1000); //lowest speed coefficent
			location <- any_location_in(one_of(intersection));
		}	
		
	}
	//Save the road agents data when cycle=100
	reflex save_road_data when: cycle > 0{
		ask road {
			if (purpose="priority"){
			save [cycle, avg_speed_vehicle, nb_drivers, nb_people, nb_wanderer, nb_bus, nb_lorry] to: "../results/tlB2_5.csv" type:"csv" rewrite: false;
			//save [cycle, nb_drivers, nb_people, nb_wanderer, nb_bus, nb_lorry] to: "../results/nb_drivers_separate.csv" type:"csv" rewrite: false;
			}
			//if (purpose="priority" and avg_speed_vehicle>0){
			//save [cycle, avg_speed_vehicle] to: "../results/speed_tlA.csv" type:"csv" rewrite: false;
		
			// save the values of the variables name, speed and size to the csv file; The file is overwritten at every save
			//save [cycle, avg_speed_vehicle, avg_speed_people, avg_speed_wanderer, avg_speed_bus, avg_speed_lorry] to: "../results/speed_separate.csv" type:"csv" rewrite: false;
			// save all the attributes values of the bug agents in a file. The file is overwritten at every save
			//save bug to: "../results/bug_agents.csv" type:"csv" rewrite: true;
			//}
		}
		if cycle=1200{
		//Pause the model as the data are saved
		do pause;
		}
	}
} 
species building {
	aspect geom {
		draw shape color: #white border: #gray;
		}
}

species intersection skills: [skill_road_node] {
 	bool is_traffic_signal;
 	bool is_crossing;
 	int a <- 1; //Coefficent to make green(TL)/red(crossing) light longer. a=1(10s), a=2(20s), a=3(30s),....
 	int b <- 1; //Coefficent to make green(TL) longer. b=0(tlA), b=1(tlB), b=3(tlC),....
	//float time_to_change <- a*30.0 +15;
	float time_to_change;
	string colourTL;
	float timingTL;
	string purpose;
	
	//int counter <- rnd (time_to_change) ;  
	float counter <- time_to_change;
	list<list> stop <- [];
	list<road> ways1;
	list<road> ways2;
	bool is_green;
	rgb color_fire;
	
	init{
		if (purpose="10G30R"){
			time_to_change <- 30.0 + 15;
		}
		else if (purpose="150G60R"){
			time_to_change <- 150.0 + b*10; // b=1, Green will be 160: 160G60R for tlB.
		}
		else if (purpose="50G160R"){
			time_to_change <- 160.0 + b*10;    // b=1, Red will be 170: 50G170R for tlB.
		}
		else if (purpose="20G10R"){
			//time_to_change <- a*10.0+10;
			time_to_change <- 20.0+10;
		}
		else if (purpose="10G20R"){
			//time_to_change <- a*20.0+10;
			time_to_change <- 30.0+10;	
		}
		else if (purpose="crossing"){
			time_to_change <- 30.0 + 5;
		}
		else{
			time_to_change <- 60.0;
		}
	}
	action compute_crossing{
		if  (length(roads_in) >= 2) {
			road rd0 <- road(roads_in[0]);
			list<point> pts <- rd0.shape.points;						
			float ref_angle <-  float( last(pts) direction_to rd0.location);
			loop rd over: roads_in {
				list<point> pts2 <- road(rd).shape.points;						
				float angle_dest <-  float( last(pts2) direction_to rd.location);
				float ang <- abs(angle_dest - ref_angle);
				if (ang > 45 and ang < 135) or  (ang > 225 and ang < 315) {
					ways2 << road(rd);
				}
			}
		}
		loop rd over: roads_in {
			if not(rd in ways2) {
				ways1 << road(rd);
			}
		}
	}
	
	
	action to_green {
		stop << [];
		color_fire <- rgb("green");
		is_green <- true;
		if  (length(roads_in) >= 2){
		do compute_crossing;
		stop[0] <- ways2 ;
		}
		
	}
	
	action to_red {
		stop<< [roads_in];
		color_fire <- rgb("red");
		is_green <- false;
		if  (length(roads_in) >= 2){
		do compute_crossing;
		stop[0] <- ways1 ;
		}
	}
	
	reflex dynamic when: is_traffic_signal or is_crossing {
		if(is_traffic_signal){
			if is_green{
				if (purpose="10G30R"){
				counter <- counter + (time_to_change/(a*10));
				}
				else if (purpose="20G10R"){
				counter <- counter + 1;   // green will be 30 cycle
				}
				else if (purpose="150G60R"){
				counter <- counter + 1;   // green will be 160 cycle
				}
				else if (purpose="50G160R"){
				counter <- counter + 3.4;   // green will be 50 cycle
				}
				else if (purpose="10G20R"){
					//counter <- counter + (time_to_change/(a*10)); //green will be 20 cycle
					counter <- counter + 2; //green will be 20 cycle
				}
				else {
					counter <- counter + 2.5;
				}
			}
			else{
				if (purpose="20G10R"){
					counter <- counter + 1; //red will be 20+10 cycle
				}
				else if (purpose="10G20R"){
				counter <- counter + 1;      //red will be 40+10 cycle
				}
				else if (purpose="150G60R"){
				counter <- counter + (8/3);      //red will be 60 cycle
				}
				else if (purpose="50G160R"){
				counter <- counter + 1;   // red will be 170 cycle
				}
				else{
				counter <- counter + 1;
				}
			}
			if (counter >= time_to_change) { 
				counter <- 0.0;
				stop[0] <- empty (stop[0]) ? roads_in : [] ;
				if is_green {
					do to_red;
				}
				else {
					do to_green;
				}
			} 
		}
		if (is_crossing){
			if is_green{
				counter <- counter + 1;
			}
			else{
			counter <- counter + 4.5;
			}
			if (counter >= time_to_change) { 
				counter <- 0;
				stop[0] <- empty (stop[0]) ? roads_in : [] ;
				if is_green {
					do to_red;
				}
				else {
					do to_green;
				}
			} 
		}
	}
	
	aspect base {
		if (is_traffic_signal) or (is_crossing) {	
			draw circle(3) color: color_fire;
		}
	}
	
	aspect base3D {
		if (is_traffic_signal) or (is_crossing){	
			draw box(1,1,10) color:rgb("black");
			draw sphere(3) at: {location.x,location.y,12} color: color_fire;
		}
	} 
}

species road skills: [skill_road] { 
	string purpose;
	int lane_priority;
	geometry geom_display;
	string oneway;
 	
 	init{
		if (purpose="priority"){
		lane_priority <-1;
		}
		else{
			return 0;
		}
	} 
	
	// -------> (km/hr)
	float avg_speed_vehicle <-0.0 update: mean((people at_distance 1#m) collect (each.real_speed*3.6) + (wanderer at_distance 1#m) collect (each.real_speed*3.6) 
		+ (bus at_distance 1#m) collect (each.real_speed*3.6) + (lorry at_distance 1#m) collect (each.real_speed*3.6));
	
	float avg_speed_people <-0.0 update: mean((people at_distance 1#m) collect (each.real_speed*3.6));
	float avg_speed_wanderer <-0.0 update: mean((wanderer at_distance 1#m) collect (each.real_speed*3.6));
	float avg_speed_bus <-0.0 update: mean((bus at_distance 1#m) collect (each.real_speed*3.6));
	float avg_speed_lorry <-0.0 update: mean((lorry at_distance 1#m) collect (each.real_speed*3.6));
	
	// -------> (mile/hr)
	/*
	float avg_speed_vehicle <-0.0 update: mean((people at_distance 1#m) collect (each.real_speed*2.2369356) + (wanderer at_distance 1#m) collect (each.real_speed*2.2369356) 
		+ (bus at_distance 1#m) collect (each.real_speed*2.2369356) + (lorry at_distance 1#m) collect (each.real_speed*2.2369356));
	
	float avg_speed_people <-0.0 update: mean((people at_distance 1#m) collect (each.real_speed*2.2369356));
	float avg_speed_wanderer <-0.0 update: mean((wanderer at_distance 1#m) collect (each.real_speed*2.2369356));
	float avg_speed_bus <-0.0 update: mean((bus at_distance 1#m) collect (each.real_speed*2.2369356));
	float avg_speed_lorry <-0.0 update: mean((lorry at_distance 1#m) collect (each.real_speed*2.2369356));
	*/
		
	int nb_people <- 0 update: length(people at_distance 1#m);
	int nb_wanderer <- 0 update: length(wanderer at_distance 1#m);
	int nb_bus <- 0 update: length(bus at_distance 1#m);
	int nb_lorry <- 0 update: length(lorry at_distance 1#m);
	
	// Count the number of vehicles on the road agent
	int nb_drivers <- 0 update: nb_people + nb_wanderer + nb_bus + nb_lorry;
	// Show the length of road agent in meter
	float length_road <- shape.perimeter/1000; // -----> (km)
	//float length_road <- 6.21371*10^(-4)*shape.perimeter; //--------> (mile)
	// Calculate the density (veh/km) on the road agent
	//float k_road <- 0.0 update: nb_drivers/(shape.perimeter/1000);   //[veh/km]
	// Calculate the flow(Q) of vehicle on the road ---------->  Greenshield, Q=Vf*k-(Vf/kj)*k^2, Vf=40km/h, kj=735veh/km
	//float Q_road <- 0.0 update: 71*k_road-(71/727)*k_road^2;
	
	aspect base { 
		if (purpose="priority")   {
		draw geom_display color: rgb("magenta");
		}
		else{
			draw shape color: rgb("gray");
		}
	} 
	aspect base3D {    
		draw geom_display color: rgb("gray") ;
	} 
}
	
species people skills: [advanced_driving] { 
	//rgb color <- rgb(rnd(255), rnd(255), rnd(255)) ;
	int counter_stucked <- 0;
	int threshold_stucked;
//	bool breakdown <- false;
	//float proba_breakdown ;
	intersection target;
	list<building> agenda1;
	list<intersection> agenda2;
	
//	reflex breakdown when: flip(proba_breakdown){
//		breakdown <- true;
//		max_speed <- 1 °km/°h;
//	}
	
	reflex time_to_go when: final_target = nil {
		target <- any_location_in(one_of(agenda2));
		current_path <- compute_path(graph: road_network, target: target);
		if (current_path = nil ) {
			final_target <- nil;
		}
	}
	reflex move when: current_path != nil and target != nil {
		do drive;
		if real_speed < 5°km/°h {
			counter_stucked<- counter_stucked + 1;
			if (counter_stucked mod threshold_stucked = 0) {
				proba_use_linked_road <- min([1.0,proba_use_linked_road + 0.1]);
			}
		} else {
			counter_stucked<- 0;
			proba_use_linked_road <- 0.0;
		}
		if(location=target.location){
			if(current_road!=nil){
				ask road(current_road){
					do unregister(myself);
				}
			}
     		do die;
     	}	
	}
	
	aspect base { 
		draw triangle(15) color: #blue rotate:heading + 90;
	} 
	aspect base3D {
		point loc <- calcul_loc();
		draw box(vehicle_length, 2,2) at: loc rotate:  heading color: #blue ;
		
		draw triangle(1.0) depth: 1.5 at: loc rotate:  heading + 90 color: #yellow;	
//		if (breakdown) {
//			draw circle(2) at: loc color: rgb("red");
//		}
	} 
	
	point calcul_loc {
		if (current_road = nil) {
			return location;
		} else {
			float val <- (road(current_road).lanes - current_lane) + 0.5;
			val <- on_linked_road ? val : val* - 1;
			if (val = 0) {
				return location; 
			} else {
				return (location + {cos(heading + 90) * val, sin(heading + 90) * val});
			}
		}
	}
	
}

species wanderer skills: [advanced_driving] { 
	int counter_stucked <- 0;
	int threshold_stucked;
	//float vehicle_length <- 3#m;
	
	reflex time_to_go when: final_target = nil {
		current_path <- compute_path(graph: road_network, target: one_of(intersection));
	}
	reflex move when: final_target != nil {
		do drive;
		if real_speed < 5°km/°h {
			counter_stucked<- counter_stucked + 1;
			if (counter_stucked mod threshold_stucked = 0) {
				proba_use_linked_road <- min([1.0,proba_use_linked_road + 0.1]);
			}
		} else {
			counter_stucked<- 0;
			proba_use_linked_road <- 0.0;
		}
	}
	aspect base { 
		draw triangle(15) color: #green rotate:heading + 90;
	} 
	
	aspect base3D {
		point loc <- calcul_loc();
		draw box(vehicle_length, 2,2) at: loc rotate:  heading color: #green ;
		
		draw triangle(1.0) depth: 1.5 at: loc rotate:  heading + 90 color: #yellow;	
	} 
	
	point calcul_loc {
		if (current_road = nil) {
			return location;
		} else {
			float val <- (road(current_road).lanes - current_lane) + 0.5;
			val <- on_linked_road ? val : val* - 1;
			if (val = 0) {
				return location; 
			} else {
				return (location + {cos(heading + 90) * val, sin(heading + 90) * val});
			}
		}
	}
} 

species bus skills: [advanced_driving] { 
	//rgb color <- rnd_color(255);
	intersection target;
	//float vehicle_length <- 14.0 #m;
	
	reflex time_to_go when: final_target = nil {
		target <- any_location_in(one_of(intersection));
		current_path <- compute_path(graph: road_network, target: target);
	}
	reflex move when: current_path != nil and target != nil {
		do drive;
		//do drive_random;
	}
	aspect base { 
		draw rectangle(15,30) color: #red rotate:heading + 90;
	} 
	
	aspect base3D {
		point loc <- calcul_loc();
		draw box(vehicle_length, 2,4) at: loc rotate:  heading color: #red ;
		
		draw triangle(1.0) depth: 1.5 at: loc rotate:  heading + 90 color: #yellow;	
	} 
	
	point calcul_loc {
		if (current_road = nil) {
			return location;
		} else {
			float val <- (road(current_road).lanes - current_lane) + 0.5;
			val <- on_linked_road ? val : val* - 1;
			if (val = 0) {
				return location; 
			} else {
				return (location + {cos(heading + 90) * val, sin(heading + 90) * val});
			}
		}
	}
}  

species lorry skills: [advanced_driving] { 
	//rgb color <- rnd_color(255);
	intersection target;
	//float vehicle_length <- 14.0 #m;
	
	reflex time_to_go when: final_target = nil {
		target <- any_location_in(one_of(intersection));
		current_path <- compute_path(graph: road_network, target: target);
	}
	reflex move when: current_path != nil and target != nil {
		do drive;
		//do drive_random;
	}
	aspect base { 
		draw rectangle(15,30) color: #black rotate:heading + 90;
	} 
	
	aspect base3D {
		point loc <- calcul_loc();
		draw box(vehicle_length, 2,4) at: loc rotate:  heading color: #black ;
		
		draw triangle(1.0) depth: 1.5 at: loc rotate:  heading + 90 color: #yellow;	
//		if (breakdown) {
//			draw circle(2) at: loc color: rgb("red");
//		}
	} 
	
	point calcul_loc {
		if (current_road = nil) {
			return location;
		} else {
			float val <- (road(current_road).lanes - current_lane) + 0.5;
			val <- on_linked_road ? val : val* - 1;
			if (val = 0) {
				return location; 
			} else {
				return (location + {cos(heading + 90) * val, sin(heading + 90) * val});
			}
		}
	}
}  

experiment experiment_2D type: gui {
	parameter "if true, simple data (simple track), if false complex one (Manhattan):" var: simple_data category: "GIS" ;
	output {
		monitor "nb_car_moving" value: people count (each.real_speed > 0.0);
		monitor "nb_wanderer_moving" value: wanderer count (each.real_speed > 0.0);
		monitor "nb_bus_moving" value: bus count (each.real_speed > 0.0);
		monitor "nb_lorry_moving" value: lorry count (each.real_speed > 0.0);
		
		monitor "Number_vehicle_on_priority_road" value: sum(road where (each.purpose="priority") collect each.nb_drivers);
		monitor "Length_priority_road" value: sum(road where (each.purpose="priority") collect each.length_road);
		monitor "Density_on_priority_road" value: sum(road where (each.purpose="priority") collect each.nb_drivers)/(sum(road where (each.purpose="priority") collect each.length_road));
		monitor "AvgSpeed_on_priority_road" value: mean(road where (each.purpose="priority" and each.avg_speed_vehicle>0) collect each.avg_speed_vehicle);		
		
		display city_display refresh: every(int(1)){
			//image file:"../images/Greenlane.png" position: {0.5,0.5};
			//image "Greenlane" file: my_file;
			species building aspect: geom refresh: false;
			species road aspect: base ;
			species intersection aspect: base;
			species people aspect: base;
			species wanderer aspect: base;
			species bus aspect: base;
			//species bus_rapid aspect: base;
			species lorry aspect: base;
		}
	/*display speed_display {
		chart "average speed" {
			data "speed" value: mean(people where (each.real_speed > 0.0) collect each.real_speed) * 3.6;
		}
	}*/
	display amount_of_user {
		chart "number of people"{
			data "moving" value: people count (each.real_speed > 0) color:#green accumulate_values:true;
		}
	}
	/*display avr_density {
			chart "average density and speed"{
				data "density" value: road count (each.density > 0);
			}
		}*/
	display speed_density_A{
		chart "speed and average density entire road network"{
			data "speed" value: mean(road collect each.avg_speed_vehicle) color: #green;
			data "density" value: sum(road collect each.nb_drivers)/(sum(road collect each.length_road)) color: #red marker_shape: marker_down_triangle;
		}
	}
	display speed_density_B{
		chart "speed and average density of road spine"{
			data "speed" value: mean(road where (each.purpose="priority" and each.avg_speed_vehicle>0) collect each.avg_speed_vehicle) color: #green;
			data "density"value: sum(road where (each.purpose="priority") collect each.nb_drivers)/(sum(road where (each.purpose="priority") collect each.length_road)) color: #red marker_shape: marker_down_triangle;
		}
	}
	}
}

experiment experiment_3D type: gui {
	parameter "if true, simple data (simple track), if false complex one (Manhattan):" var: simple_data category: "GIS" ;
	output {
		monitor "nb_car_moving" value: people count (each.real_speed > 0.0);
		monitor "nb_wanderer_moving" value: wanderer count (each.real_speed > 0.0);
		monitor "nb_bus_moving" value: bus count (each.real_speed > 0.0);
		monitor "nb_lorry_moving" value: lorry count (each.real_speed > 0.0);
		
		monitor "Number_vehicle_on_priority_road" value: sum(road where (each.purpose="priority") collect each.nb_drivers);
		monitor "Length_priority_road" value: sum(road where (each.purpose="priority") collect each.length_road);
		monitor "Density_on_priority_road" value: sum(road where (each.purpose="priority") collect each.nb_drivers)/(sum(road where (each.purpose="priority") collect each.length_road));
		monitor "AvgSpeed_on_priority_road" value: mean(road where (each.purpose="priority" and each.avg_speed_vehicle>0) collect each.avg_speed_vehicle);
				
		display carte_principale type: opengl ambient_light: 100{
			//image "Greenlane" file: my_file position: {0.05, 0.05} size: {0.9, 0.9};
			species building aspect: geom refresh: false;
			species road aspect: base3D refresh: true;
			species intersection aspect: base3D;
			species people aspect: base3D ; 
			species wanderer aspect: base3D ;
			species bus aspect: base3D ;
			species lorry aspect: base3D ;
		}
		display speed_display {
			chart "average speed" {
				data "speed" value: mean(people where (each.real_speed > 0.0) collect each.real_speed) * 3.6;
			}
		}
		display speed_density_A{
		chart "speed and average density entire road network"{
			data "speed" value: mean(road collect each.avg_speed_vehicle) color: #green;
			data "density" value: sum(road collect each.nb_drivers)/(sum(road collect each.length_road)) color: #red;
		}
	}
	display speed_density_B{
		chart "speed and average density of road spine"{
			data "speed" value: mean(road where (each.purpose="priority" and each.avg_speed_vehicle>0) collect each.avg_speed_vehicle) color: #green;
			data "density" value: sum(road where (each.purpose="priority") collect each.nb_drivers)/(sum(road where (each.purpose="priority") collect each.length_road)) color: #red;
		}
	}
	}
}
