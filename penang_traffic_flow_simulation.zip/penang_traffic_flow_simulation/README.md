# Agent-Based Traffic Simulation of a Georgetown Road: Simulation and Output Analysis

An agent-based simulation of urban traffic on a road in Georgetown, Penang, built in GAMA, plus Python notebooks that turn the raw simulation output into traffic measures (average speed and density) and fit models of how speed falls as the road fills with vehicles.

This work comes from my time as a Graduate Research Assistant at Universiti Sains Malaysia and led to a peer-reviewed paper (see [Related publications](#related-publications)). This repository shares a selected part of the analysis, not the full project.

**Skills shown:** agent-based modelling (GAMA), GIS data preparation (QGIS, OpenStreetMap), data wrangling with pandas, nonlinear least-squares model fitting with SciPy, and clear scientific communication.

---

## 1. Problem

Traffic congestion is a daily problem in dense cities. It is hard to study directly because road users are mixed (cars, delivery vehicles, buses, lorries), each driver behaves differently, and traffic lights change how vehicles queue and flow. Simple equations struggle to capture this, and measured traffic data was not available for this study.

**The question:** on a real road in Georgetown, Penang, how do vehicle composition and traffic-light timing affect traffic flow, and how does average speed fall as the road becomes more crowded?

**Study site:** a multi-lane road segment of about 1.04 km in Greenlane, Georgetown, with a traffic signal at its end. The road network comes from OpenStreetMap.

## 2. My contribution

| Part | What I did |
|---|---|
| **Simulation model (GAMA / GAML)** | Built the agent-based model: vehicle agents (people, wanderers such as couriers and e-hailing, buses, lorries) with their own speed, acceleration and lane-changing behaviour; traffic-light agents with red/green timing; and the experiments that produce the output files. |
| **GIS preparation (QGIS)** | Prepared the OpenStreetMap road network used as the simulation environment. |
| **Data processing (Python)** | Wrote the functions that turn raw simulation output into per-cycle average speed and density. |
| **Analysis (Python)** | Averaged repeated runs, fitted and compared speed–density models, and produced the plots. |
| **Communication** | Wrote up the methodology and findings as a first-author, peer-reviewed paper, and documented the notebooks for readers outside the field. |

Research supervised by Md Yushalify Misro (Universiti Sains Malaysia). [ADD: adjust this table if the split of work was different.]

## 3. Tools

| Purpose | Tools |
|---|---|
| Simulation | GAMA platform, GAML |
| GIS | QGIS, OpenStreetMap |
| Analysis | Python, pandas, NumPy, SciPy (`optimize.minimize`, `stats.linregress`), matplotlib |
| Environment | Jupyter Notebook |

## 4. Methodology

### 4.1 The simulation

The model represents the road as a network along which vehicle agents travel from an origin to a destination, or wander randomly. Vehicles slow down, speed up, change lanes and stop at red lights according to their own behaviour parameters. Traffic-light agents switch between red and green after a set number of simulation steps. Each simulation runs for **1,000 cycles**, and every scenario was run **5 times**, because the model has random elements.

- **Scenario 1:** [ADD: one sentence, for example the traffic-light setting and demand level]
- **Scenario 2:** [ADD: one sentence]

### 4.2 The data

Each run produces one CSV file. Each row records one road segment in one cycle: the cycle number, the average speed of vehicles there, and the number of vehicles (total, and split into people, wanderers, buses and lorries).

| File | Contents |
|---|---|
| `tlB_1.csv` to `tlB_5.csv` | Raw output, Scenario 1, runs 1 to 5 |
| `tlB2_1.csv` to `tlB2_5.csv` | Raw output, Scenario 2, runs 1 to 5 |
| `new_*.csv` | Processed per-cycle results written by the notebook |

### 4.3 The analysis (in the notebook)

1. **Aggregate each cycle.** Total speed is the speed on each row multiplied by its vehicle count, summed across the road. **Average speed** is total speed divided by total vehicles, so busier road segments count for more. **Density** is total vehicles divided by road length (1.0448 km). Cycles with no vehicles have no defined speed and are skipped in later averaging and fitting.
2. **Average the five runs** for each cycle, to reduce the randomness of any single run.
3. **Fit two models** of how speed depends on density:
   - **Linear model:** `speed = a × density + b`, fitted by linear regression (the classic Greenshields assumption).
   - **MacNicholas model:** a nonlinear curve, `speed = u_f × (k_j^z − k^z) / (k_j^z + m × k^z)`, where `u_f` is free-flow speed, `k_j` is jam density and `k` is density. The shape parameters `m` and `z` are estimated by minimizing the mean squared error between the model and the simulated speeds (L-BFGS-B, with `m ≥ 0` and `z ≥ 1`). `u_f` and `k_j` are fixed at 60.58 km/h and 626 veh/km. [ADD: where these two values came from.]
4. **Compare** the two fits against the data.

## 5. Results

![Speed against density with linear and MacNicholas fits, Scenario 1](figures/scenario1_speed_density_fit.png)

**Scenario 1: congestion builds up and does not clear.** Density rises steadily across the 1,000 cycles, to about 340 veh/km on average, while average speed falls from about 50 km/h early on to roughly 1 km/h. Speed drops fastest at low density and flattens out near standstill. The MacNicholas curve follows this curved shape much more closely than the straight line (`speed = −0.0800 × density + 23.200`). Fitted shape parameters: `m ≈ 27.43`, `z ≈ 1.09`.

![Density and average speed over time, Scenario 2](figures/scenario2_averaged_runs.png)

**Scenario 2: congestion builds, then clears.** Density rises to a peak of about 55 veh/km around cycle 200 and then falls, with smaller waves afterwards. Average speed drops sharply at the peak and recovers as the road clears. The MacNicholas fit gives `m ≈ 4013.67`, `z ≈ 2.78`, but this scenario never gets close to the jam density, so the fit is only reliable at low and moderate density (see limitations).

**What this shows:** the relationship between speed and density on this road is clearly nonlinear, so a straight-line model misses the sharp drop at low density and the long flat tail near standstill. Averaging repeated runs gives a much clearer picture than any single run.

The related published paper reports the main findings on vehicle composition and traffic-light timing (see below). The notebooks here add a nonlinear speed–density fit on selected simulation output.

## 6. Reproducibility

### Repository structure

```
.
├── gama_model/          GAMA model files and OpenStreetMap inputs
├── data/                Raw simulation output (CSV) and processed files
├── notebooks/           Jupyter notebooks (one per simulation setup)
├── figures/             Plots used in this README
├── requirements.txt
└── README.md
```

[ADD: adjust to match your actual folders.]

### Run the analysis

1. Install Python 3 and the packages:
   ```
   pip install -r requirements.txt
   ```
   `requirements.txt` needs: `pandas`, `numpy`, `scipy`, `matplotlib`, `jupyter`. [ADD: pin versions from `pip freeze`.]
2. Open the notebook in `notebooks/` with Jupyter.
3. Run all cells (`Kernel > Restart & Run All`). The notebook reads the raw CSV files from `data/` and writes the processed files back to `data/`.

### Re-run the simulation

Open the model in GAMA [ADD: GAMA version, model file name and experiment name], run the experiment for 1,000 cycles, and export the output CSV for each run. Because the model has random elements, individual runs will differ slightly. The averaged results should look similar.

### Data note

The CSV files are output from my own simulation, so they are not real traffic measurements. The `data/` folder contains only the part of the analysis shown here.

## 7. Limitations and next steps

**Assumptions and limits**
- **The data is simulated.** Traffic demand levels were scenario settings, because measured traffic data for the road was not available. Results show how the model behaves, not measured conditions on the road.
- **One road segment** of about 1 km, with a single signal.
- **Fixed model constants.** Free-flow speed and jam density are fixed inputs and are the same for both scenarios, rather than estimated from each scenario's data.
- **Limited density range in Scenario 2.** Density stays far below the assumed jam density, so the fitted shape parameters are poorly constrained.
- **Five runs per scenario.** Enough to see the pattern, but not to put tight confidence bands on it.
- **Model comparison is visual.** There are no numeric error measures yet.
- **Four-wheeled vehicles only** were modelled.

**What I would improve**
- Add numeric goodness-of-fit measures (RMSE, R²) for both models.
- Estimate free-flow speed and jam density from each scenario instead of fixing them.
- Show variation between runs (for example, shaded bands) instead of only the mean.
- Calibrate and validate against real traffic counts.
- Include motorcycles and other two-wheeled vehicles.

## Related publications

- Shaharuddin, R.A.; Misro, M.Y. *Controlling Traffic Congestion in Urbanised City: A Framework Using Agent-Based Modelling and Simulation Approach.* ISPRS International Journal of Geo-Information **2023**, 12(6), 226. https://doi.org/10.3390/ijgi12060226 (open access)
- Shaharuddin, R.A.; Misro, M.Y. *Traffic Simulation Using Agent-Based Modelling.* AIP Conference Proceedings **2021**, 2423, 020035.

The 2023 paper uses a linear (Greenshields) speed–density relationship and studies vehicle composition and traffic-light timing at peak and off-peak hours. The notebooks in this repository additionally fit the nonlinear MacNicholas model to selected output.

## Contact

Raihanah Adawiyah Shaharuddin · [LinkedIn](https://www.linkedin.com/in/raihanah-adawiyah-shaharuddin/) · raihanahadwyh@gmail.com

[ADD: licence, for example MIT for the code.]
